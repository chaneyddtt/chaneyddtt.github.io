clear;

% create synthetic view graph
numofcam = 200; 
ratio_obser = 0.5;
ratio_outlier = 0.2;
sigma = 5;
[tij_index,tij_observe,t_gt]=syntheticgraph(numofcam,ratio_obser,ratio_outlier,sigma);

% Translation Averaging
param.delta = 10^-6;
param.numofiterinit = 10;
param.numofouteriter = 10;
param.numofinneriter = 10;
param.robustthre = 10^-1;
t=BATA(tij_index,tij_observe,param);

                                                         

    
